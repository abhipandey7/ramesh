const labels = [];
const dataset = [];
let API = "http://webapi19sa-1.course.tamk.cloud/v1/weather/wind_speed/";

function setParams(query) {
    API = API.concat(query.toString());
    this.fetch(API);
    return API = "http://webapi19sa-1.course.tamk.cloud/v1/weather/wind_speed/";
}

fetch(API)
    .then(function (response) {
        return response.json();
    })
    .then(function (weaterdata) {
        let placeholder = document.querySelector('#data-output');
        let out = "";
        for (const [i, data] of weaterdata.entries()) {
            labels.push((new Date(data.date_time).getUTCHours() + ":" + new Date(data.date_time).getUTCMinutes() + ":" + new Date(data.date_time).getUTCSeconds()).toString());
            dataset.push(data.wind_speed);
            out += `
                <tr>
                    <td>${i + 1}</td>
                    <td>${new Date(data.date_time).toDateString()}</td>
                    <td>${new Date(data.date_time).toLocaleTimeString()}</td>
                    <td>${data.wind_speed}</td>
                </tr >
                `;
        }
        placeholder.innerHTML = out;
    })

const data = {
    labels: labels,
    datasets: [{
        label: 'Wind Speed Record Record',
        backgroundColor: 'rgb(255, 99, 132)',
        borderColor: 'rgb(255, 99, 132)',
        data: dataset,
    }]
};

const config = {
    type: 'bar',
    data: data,
    options: {}
};

function myFunction() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("data-output");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[2];
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}